truncate product_tbl;

insert into product_tbl
	(product_id,title, artist, style, format, price, genre, quantity)
values
	(0,'Testing1', 'Tester', 'folk', 'digital', 15, 'rock', 3);
insert into product_tbl
	(product_id,title, artist, style, format, price, genre, quantity)
values
	(0,'Testing2', 'Tester', 'folk', 'digital', 15, 'rock', 3);
insert into product_tbl
	(product_id,title, artist, style, format, price, genre, quantity)
values
	(0,'Testing3', 'Tester', 'symphony', 'cd', 15, 'rock', 3);
insert into product_tbl
	(product_id,title, artist, style, format, price, genre, quantity)
values
	(0,'Does it Really Work?', 'Joe Mama', 'hard core', 'vinyl', 15, 'electronic', 3);