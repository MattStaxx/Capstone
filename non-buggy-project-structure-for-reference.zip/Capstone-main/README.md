# Capstone
Flowchart Link:https://lucid.app/lucidchart/invitations/accept/inv_43da5a1b-0147-4ff8-afaf-a33464c7b84c?viewport_loc=188%2C193%2C1280%2C617%2C0_0
